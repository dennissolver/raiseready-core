'use client';

import { useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { CheckCircle, Circle, Loader2, XCircle, ExternalLink, RotateCcw, Sparkles, Globe, Trash2, MinusCircle } from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

type PlatformType = 'impact_investor' | 'commercial_investor' | 'family_office' | 'founder_service_provider';
type StepStatus = 'pending' | 'running' | 'success' | 'error' | 'skipped';

interface Step {
  id: string;
  label: string;
  description: string;
  status: StepStatus;
  message?: string;
  error?: string;
  duration?: number;
  isCleanup?: boolean;
}

interface ExtractedBranding {
  company: { name: string; tagline: string; description: string; website: string };
  colors: { primary: string; accent: string; background: string; text: string };
  logo: { url: string | null; base64: string | null };
  thesis: { focusAreas: string[]; sectors: string[]; philosophy: string };
  contact: { email: string | null; phone: string | null; linkedin: string | null };
  platformType: PlatformType;
}

interface FormData {
  companyName: string;
  companyWebsite: string;
  companyEmail: string;
  adminFirstName: string;
  adminLastName: string;
  adminEmail: string;
  adminPhone: string;
  agentName: string;
  voiceGender: 'female' | 'male';
  platformType: PlatformType;
  branding: ExtractedBranding | null;
}

interface OrchestrationResult {
  success: boolean;
  platformUrl: string | null;
  steps: Array<{ step: string; status: string; message?: string; error?: string; duration?: number }>;
  resources: {
    supabase: { projectId: string; url: string } | null;
    github: { repoUrl: string; repoName: string } | null;
    vercel: { projectId: string; url: string } | null;
    elevenlabs: { agentId: string } | null;
  };
  rollback?: { performed: boolean };
  error?: string;
  duration?: number;
}

// ============================================================================
// STEP DEFINITIONS
// ============================================================================

const STEP_CONFIG: Record<string, { label: string; description: string; isCleanup?: boolean }> = {
  'cleanup-supabase': { label: 'Checking Supabase', description: 'Looking for existing project...', isCleanup: true },
  'cleanup-vercel': { label: 'Checking Vercel', description: 'Looking for existing deployment...', isCleanup: true },
  'cleanup-github': { label: 'Checking GitHub', description: 'Looking for existing repository...', isCleanup: true },
  'create-supabase': { label: 'Creating Supabase', description: 'Setting up database...' },
  'run-migrations': { label: 'Applying schema', description: 'Creating tables and policies...' },
  'create-elevenlabs': { label: 'Creating voice agent', description: 'Setting up AI coaching...' },
  'create-github': { label: 'Creating repository', description: 'Pushing platform code...' },
  'create-vercel': { label: 'Creating deployment', description: 'Configuring hosting...' },
  'configure-auth': { label: 'Configuring auth', description: 'Setting up login...' },
  'trigger-deployment': { label: 'Deploying platform', description: 'Building your site...' },
  'send-welcome-email': { label: 'Sending welcome email', description: 'Notifying admin...' },
};

const STEP_ORDER = [
  'cleanup-supabase', 'cleanup-vercel', 'cleanup-github',
  'create-supabase', 'run-migrations', 'create-elevenlabs',
  'create-github', 'create-vercel', 'configure-auth',
  'trigger-deployment', 'send-welcome-email',
];

function getInitialSteps(): Step[] {
  return STEP_ORDER.map(id => ({
    id,
    label: STEP_CONFIG[id].label,
    description: STEP_CONFIG[id].description,
    status: 'pending' as StepStatus,
    isCleanup: STEP_CONFIG[id].isCleanup,
  }));
}

// ============================================================================
// COMPONENTS
// ============================================================================

function StepIcon({ status, isCleanup }: { status: StepStatus; isCleanup?: boolean }) {
  const size = isCleanup ? 'w-4 h-4' : 'w-5 h-5';

  switch (status) {
    case 'success':
      return <CheckCircle className={`${size} ${isCleanup ? 'text-orange-400' : 'text-green-500'}`} />;
    case 'error':
      return <XCircle className={`${size} text-red-500`} />;
    case 'running':
      return <Loader2 className={`${size} ${isCleanup ? 'text-orange-400' : 'text-blue-500'} animate-spin`} />;
    case 'skipped':
      return <MinusCircle className={`${size} text-gray-500`} />;
    default:
      return <Circle className={`${size} text-gray-600`} />;
  }
}

function StepItem({ step, isLast }: { step: Step; isLast: boolean }) {
  const isCleanup = step.isCleanup;

  // Dynamic description based on message
  let displayDescription = step.description;
  if (step.message) {
    displayDescription = step.message;
  } else if (step.error) {
    displayDescription = step.error;
  }

  return (
    <div className={`flex gap-3 ${isCleanup ? 'opacity-90' : ''}`}>
      <div className="flex flex-col items-center">
        <StepIcon status={step.status} isCleanup={isCleanup} />
        {!isLast && (
          <div className={`w-0.5 flex-1 min-h-[24px] mt-1 ${
            step.status === 'success' ? (isCleanup ? 'bg-orange-500/50' : 'bg-green-500/50') : 
            step.status === 'error' ? 'bg-red-500/50' : 'bg-gray-700'
          }`} />
        )}
      </div>
      <div className={`flex-1 ${isCleanup ? 'pb-3' : 'pb-5'}`}>
        <div className="flex items-center gap-2">
          <h3 className={`${isCleanup ? 'text-sm' : 'font-medium'} ${
            step.status === 'running' ? (isCleanup ? 'text-orange-300' : 'text-blue-400') :
            step.status === 'success' ? (isCleanup ? 'text-orange-300' : 'text-green-400') :
            step.status === 'error' ? 'text-red-400' :
            step.status === 'skipped' ? 'text-gray-500' : 'text-gray-400'
          }`}>
            {step.label}
          </h3>
          {step.duration && step.duration > 0 && (
            <span className="text-xs text-gray-500">({(step.duration / 1000).toFixed(1)}s)</span>
          )}
        </div>
        <p className={`text-sm ${step.status === 'error' ? 'text-red-400' : 'text-gray-500'} ${isCleanup ? 'text-xs' : ''}`}>
          {displayDescription}
        </p>
      </div>
    </div>
  );
}

function ColorSwatch({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="w-6 h-6 rounded border border-gray-600" style={{ backgroundColor: color }} />
      <span className="text-sm text-gray-400">{label}: {color}</span>
    </div>
  );
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
    </div>
  );
}

// ============================================================================
// MAIN SETUP CONTENT
// ============================================================================

function SetupContent() {
  const searchParams = useSearchParams();
  const platformType = (searchParams.get('type') as PlatformType) || 'commercial_investor';

  const [currentStep, setCurrentStep] = useState<'form' | 'extracting' | 'review' | 'creating' | 'success' | 'error'>('form');
  const [steps, setSteps] = useState<Step[]>(getInitialSteps());
  const [result, setResult] = useState<OrchestrationResult | null>(null);
  const [extractionError, setExtractionError] = useState<string | null>(null);
  const [formData, setFormData] = useState<FormData>({
    companyName: '',
    companyWebsite: '',
    companyEmail: '',
    adminFirstName: '',
    adminLastName: '',
    adminEmail: '',
    adminPhone: '',
    agentName: 'Maya',
    voiceGender: 'female',
    platformType,
    branding: null,
  });

  const platformLabels: Record<PlatformType, string> = {
    impact_investor: 'Impact Investor Platform',
    commercial_investor: 'Commercial Investor Platform',
    family_office: 'Family Office Platform',
    founder_service_provider: 'Founder Service Provider Platform',
  };

  // ============================================================================
  // STEP PROGRESS SIMULATION (while waiting for orchestrator)
  // ============================================================================

  const startProgressSimulation = () => {
    let currentIdx = 0;

    const interval = setInterval(() => {
      setSteps(prev => {
        const newSteps = [...prev];

        // Mark current as running
        if (currentIdx < newSteps.length) {
          // Mark previous as success (simulation)
          if (currentIdx > 0 && newSteps[currentIdx - 1].status === 'running') {
            newSteps[currentIdx - 1].status = 'success';
          }

          // If still pending, mark as running
          if (newSteps[currentIdx].status === 'pending') {
            newSteps[currentIdx].status = 'running';
          }

          currentIdx++;
        }

        return newSteps;
      });

      // Stop after all steps
      if (currentIdx >= STEP_ORDER.length) {
        clearInterval(interval);
      }
    }, 800);

    return () => clearInterval(interval);
  };

  // ============================================================================
  // UPDATE STEPS FROM REAL RESULT
  // ============================================================================

  const updateStepsFromResult = (result: OrchestrationResult) => {
    setSteps(prev => {
      const newSteps = [...prev];

      for (const resultStep of result.steps) {
        const idx = newSteps.findIndex(s => s.id === resultStep.step);
        if (idx !== -1) {
          newSteps[idx] = {
            ...newSteps[idx],
            status: resultStep.status === 'success' ? 'success' :
                    resultStep.status === 'error' ? 'error' :
                    resultStep.status === 'skipped' ? 'skipped' : 'pending',
            message: resultStep.message,
            error: resultStep.error,
            duration: resultStep.duration,
          };
        }
      }

      // Mark any remaining pending steps as skipped if we had an error
      if (!result.success) {
        newSteps.forEach((step, idx) => {
          if (step.status === 'pending' || step.status === 'running') {
            newSteps[idx] = { ...step, status: 'skipped', message: 'Skipped due to error' };
          }
        });
      }

      return newSteps;
    });
  };

  // ============================================================================
  // EXTRACTION
  // ============================================================================

  const handleExtract = async () => {
    if (!formData.companyWebsite) {
      setExtractionError('Please enter a website URL');
      return;
    }

    setCurrentStep('extracting');
    setExtractionError(null);

    try {
      const response = await fetch('/api/setup/extract-branding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ websiteUrl: formData.companyWebsite }),
      });

      const data = await response.json();

      if (data.success && data.branding) {
        setFormData(prev => ({
          ...prev,
          companyName: data.branding.company.name || prev.companyName,
          companyEmail: data.branding.contact?.email || prev.companyEmail,
          platformType: data.branding.platformType || prev.platformType,
          branding: data.branding,
        }));
        setCurrentStep('review');
      } else {
        setExtractionError(data.error || 'Extraction failed');
        setCurrentStep('form');
      }
    } catch (error: any) {
      setExtractionError(error.message || 'Failed to extract branding');
      setCurrentStep('form');
    }
  };

  const handleSkipExtraction = () => {
    setFormData(prev => ({
      ...prev,
      branding: {
        company: { name: prev.companyName, tagline: 'AI-Powered Pitch Coaching', description: '', website: prev.companyWebsite },
        colors: { primary: '#8B5CF6', accent: '#10B981', background: '#0F172A', text: '#F8FAFC' },
        logo: { url: null, base64: null },
        thesis: { focusAreas: [], sectors: [], philosophy: '' },
        contact: { email: prev.companyEmail, phone: null, linkedin: null },
        platformType: prev.platformType,
      },
    }));
    setCurrentStep('review');
  };

  // ============================================================================
  // ORCHESTRATION
  // ============================================================================

  const handleCreate = async () => {
    setCurrentStep('creating');
    setSteps(getInitialSteps());

    // Start simulation
    const stopSimulation = startProgressSimulation();

    try {
      const response = await fetch('/api/setup/orchestrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyName: formData.companyName,
          companyWebsite: formData.companyWebsite,
          companyEmail: formData.companyEmail,
          adminFirstName: formData.adminFirstName,
          adminLastName: formData.adminLastName,
          adminEmail: formData.adminEmail,
          adminPhone: formData.adminPhone,
          agentName: formData.agentName,
          voiceGender: formData.voiceGender,
          platformMode: 'screening',
          branding: formData.branding,
        }),
      });

      const data: OrchestrationResult = await response.json();
      stopSimulation();
      setResult(data);
      updateStepsFromResult(data);
      setCurrentStep(data.success ? 'success' : 'error');
    } catch (error: any) {
      stopSimulation();
      setCurrentStep('error');
      setResult({
        success: false,
        platformUrl: null,
        steps: [],
        resources: { supabase: null, github: null, vercel: null, elevenlabs: null },
        error: error.message || 'An unexpected error occurred',
      });
    }
  };

  const handleRetry = () => {
    setCurrentStep('form');
    setSteps(getInitialSteps());
    setResult(null);
    setFormData(prev => ({ ...prev, branding: null }));
  };

  // ============================================================================
  // RENDER: FORM
  // ============================================================================

  if (currentStep === 'form') {
    return (
      <div className="min-h-screen bg-slate-950 text-white py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">RaiseReady Platform Setup</h1>
            <p className="text-gray-400">Create a white-label pitch coaching platform</p>
            <div className="mt-4 inline-block px-4 py-2 bg-purple-500/20 rounded-full text-purple-300 text-sm">
              {platformLabels[platformType]}
            </div>
          </div>

          <div className="space-y-6 bg-slate-900 rounded-xl p-8">
            <div>
              <label className="block text-sm font-medium mb-1">Company Website *</label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={formData.companyWebsite}
                  onChange={e => setFormData(prev => ({ ...prev, companyWebsite: e.target.value }))}
                  className="flex-1 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg focus:ring-2 focus:ring-purple-500"
                  placeholder="https://acme.vc"
                />
                <button
                  onClick={handleExtract}
                  className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg font-medium"
                >
                  <Sparkles className="w-4 h-4" />
                  Extract
                </button>
              </div>
              {extractionError && <p className="text-sm text-red-400 mt-2">{extractionError}</p>}
            </div>

            <div className="text-center text-gray-500">— or —</div>

            <button
              onClick={handleSkipExtraction}
              className="w-full py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold"
            >
              Configure Manually
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // RENDER: EXTRACTING
  // ============================================================================

  if (currentStep === 'extracting') {
    return (
      <div className="min-h-screen bg-slate-950 text-white py-12 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <Globe className="w-16 h-16 text-purple-500 mx-auto mb-4 animate-pulse" />
          <h1 className="text-2xl font-bold mb-2">Extracting Branding</h1>
          <p className="text-gray-400">{formData.companyWebsite}</p>
          <div className="flex items-center justify-center gap-2 mt-4 text-purple-400">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Analyzing website...</span>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // RENDER: REVIEW
  // ============================================================================

  if (currentStep === 'review') {
    const branding = formData.branding!;

    return (
      <div className="min-h-screen bg-slate-950 text-white py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Review & Configure</h1>
            <p className="text-gray-400">Confirm details before creating</p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); handleCreate(); }} className="space-y-6 bg-slate-900 rounded-xl p-8">
            {/* Branding Preview */}
            <div className="bg-slate-800 rounded-lg p-4 space-y-3">
              <h3 className="font-medium text-purple-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> Extracted Branding
              </h3>
              {branding.logo.url && (
                <img src={branding.logo.base64 || branding.logo.url} alt="Logo" className="h-10 w-auto" />
              )}
              <div className="flex flex-wrap gap-4">
                <ColorSwatch color={branding.colors.primary} label="Primary" />
                <ColorSwatch color={branding.colors.accent} label="Accent" />
              </div>
            </div>

            {/* Company */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold border-b border-slate-700 pb-2">Company</h2>
              <div>
                <label className="block text-sm font-medium mb-1">Company Name *</label>
                <input
                  type="text"
                  required
                  value={formData.companyName}
                  onChange={e => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Company Email *</label>
                <input
                  type="email"
                  required
                  value={formData.companyEmail}
                  onChange={e => setFormData(prev => ({ ...prev, companyEmail: e.target.value }))}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                />
              </div>
            </div>

            {/* Admin */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold border-b border-slate-700 pb-2">Administrator</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.adminFirstName}
                    onChange={e => setFormData(prev => ({ ...prev, adminFirstName: e.target.value }))}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.adminLastName}
                    onChange={e => setFormData(prev => ({ ...prev, adminLastName: e.target.value }))}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Admin Email *</label>
                <input
                  type="email"
                  required
                  value={formData.adminEmail}
                  onChange={e => setFormData(prev => ({ ...prev, adminEmail: e.target.value }))}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                />
              </div>
            </div>

            {/* Voice */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold border-b border-slate-700 pb-2">AI Coach</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name</label>
                  <input
                    type="text"
                    value={formData.agentName}
                    onChange={e => setFormData(prev => ({ ...prev, agentName: e.target.value }))}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Voice</label>
                  <select
                    value={formData.voiceGender}
                    onChange={e => setFormData(prev => ({ ...prev, voiceGender: e.target.value as 'female' | 'male' }))}
                    className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
                  >
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                  </select>
                </div>
              </div>
            </div>

            <button type="submit" className="w-full py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-semibold">
              Create Platform
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ============================================================================
  // RENDER: CREATING / SUCCESS / ERROR
  // ============================================================================

  const cleanupSteps = steps.filter(s => s.isCleanup);
  const creationSteps = steps.filter(s => !s.isCleanup);

  return (
    <div className="min-h-screen bg-slate-950 text-white py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {currentStep === 'creating' && 'Creating Your Platform'}
            {currentStep === 'success' && 'Platform Created!'}
            {currentStep === 'error' && 'Setup Failed'}
          </h1>
          <p className="text-gray-400">
            {currentStep === 'creating' && 'This may take 2-3 minutes...'}
            {currentStep === 'success' && 'Your platform is ready'}
            {currentStep === 'error' && 'An error occurred'}
          </p>
        </div>

        <div className="bg-slate-900 rounded-xl p-8">
          {/* Cleanup Steps */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-orange-400 mb-3 flex items-center gap-2">
              <Trash2 className="w-4 h-4" />
              Pre-flight Cleanup
            </h3>
            <div className="pl-2 border-l border-orange-500/30">
              {cleanupSteps.map((step, idx) => (
                <StepItem key={step.id} step={step} isLast={idx === cleanupSteps.length - 1} />
              ))}
            </div>
          </div>

          <div className="border-t border-slate-700 my-6" />

          {/* Creation Steps */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-blue-400 mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Platform Creation
            </h3>
            {creationSteps.map((step, idx) => (
              <StepItem key={step.id} step={step} isLast={idx === creationSteps.length - 1} />
            ))}
          </div>

          {/* Success */}
          {currentStep === 'success' && result && (
            <div className="border-t border-slate-700 pt-6 space-y-4">
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <h3 className="text-green-400 font-semibold mb-2">Your platform is live!</h3>
                <a
                  href={result.platformUrl || '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-green-300 hover:text-green-200"
                >
                  {result.platformUrl}
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>

              {result.resources.github && (
                <div className="bg-slate-800 rounded-lg p-4">
                  <h4 className="text-sm text-gray-400 mb-1">GitHub Repository</h4>
                  <a
                    href={result.resources.github.repoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-blue-400 hover:text-blue-300"
                  >
                    {result.resources.github.repoUrl}
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              )}

              {result.duration && (
                <p className="text-sm text-gray-500 text-center">
                  Completed in {(result.duration / 1000).toFixed(1)}s
                </p>
              )}
            </div>
          )}

          {/* Error */}
          {currentStep === 'error' && result && (
            <div className="border-t border-slate-700 pt-6 space-y-4">
              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                <h3 className="text-red-400 font-semibold mb-2">Error</h3>
                <p className="text-red-300">{result.error}</p>
              </div>

              {result.rollback?.performed && (
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                  <p className="text-yellow-300 text-sm">Resources have been cleaned up.</p>
                </div>
              )}

              <button
                onClick={handleRetry}
                className="w-full flex items-center justify-center gap-2 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold"
              >
                <RotateCcw className="w-4 h-4" />
                Try Again
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function SetupPage() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <SetupContent />
    </Suspense>
  );
}